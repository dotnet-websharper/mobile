module AssemblyInfo

open System.Reflection
open System.Runtime.InteropServices

[<assembly: AssemblyProduct "WebSharper Mobile App">]
[<assembly: AssemblyCompany "Company">]
[<assembly: Guid "e7b1b3d8-05f0-45a2-8b04-81f0dec7e214">]
[<assembly: AssemblyFileVersion "1.0.0.0">]
[<assembly: AssemblyDescription "An app built using WebSharper Mobile">]
do ()